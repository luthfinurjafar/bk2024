<?php
session_start(); // Memulai sesi

// Cek apakah id_pasien ada di session
if (!isset($_SESSION['id_pasien'])) {
    echo "<script>alert('Anda harus login sebagai pasien terlebih dahulu.');</script>";
    exit;
}

$id_pasien = $_SESSION['id_pasien']; // Ambil id_pasien dari session

// Koneksi database
$databaseHost = 'localhost';
$databaseName = 'poli_bk';
$databaseUsername = 'root';
$databasePassword = '';
$mysqli = new mysqli($databaseHost, $databaseUsername, $databasePassword, $databaseName);

// Cek apakah koneksi berhasil
if ($mysqli->connect_error) {
    die("Koneksi gagal: " . $mysqli->connect_error);
}

$success_message = $error = "";
$jam_mulai = $jam_selesai = ""; // Variabel untuk menyimpan jam mulai dan jam selesai

// Periksa apakah form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $keluhan = $_POST['keluhan'];
    $id_jadwal = $_POST['id_jadwal'];
    $id_pasien = $_SESSION['id_pasien']; // Mengambil id_pasien dari sesi
    $jadwal_periksa = $_POST['tanggal_pemeriksaan']; // Tanggal pemeriksaan yang dipilih

    // Cek apakah jadwal dipilih
    if (empty($id_jadwal)) {
        $error = "Jadwal belum dipilih atau tidak tersedia.";
    } else {
        // Hitung nomor antrian berdasarkan jumlah pasien yang sudah mendaftar untuk jadwal ini pada tanggal pemeriksaan
        $query_antrian = "SELECT COUNT(*) AS antrian FROM daftar_poli WHERE id_jadwal = '$id_jadwal' AND jadwal_periksa = '$jadwal_periksa'";
        $result_antrian = mysqli_query($mysqli, $query_antrian);
        $row_antrian = mysqli_fetch_assoc($result_antrian);
        $no_antrian = $row_antrian['antrian'] + 1; // Nomor antrian bertambah 1

        // Ambil detail jadwal berdasarkan id_jadwal yang dipilih
        $query_jadwal = "SELECT jd.jam_mulai, jd.jam_selesai, p.nama_poli, d.nama 
                         FROM jadwal_dokter jd 
                         JOIN dokter d ON jd.id_dokter = d.id 
                         JOIN poli p ON d.id_poli = p.id 
                         WHERE jd.id = '$id_jadwal'";
        $result_jadwal = mysqli_query($mysqli, $query_jadwal);

        // Debugging: Periksa apakah query berhasil
        if (!$result_jadwal) {
            die("Query gagal: " . mysqli_error($mysqli));
        }

        $row_jadwal = mysqli_fetch_assoc($result_jadwal);

        // Ambil data dari query
        $jam_mulai = $row_jadwal['jam_mulai'];
        $jam_selesai = $row_jadwal['jam_selesai'];
        $poli = $row_jadwal['nama_poli'];
        $dokter = $row_jadwal['nama'];

        // Masukkan pendaftaran poli baru ke tabel daftar_poli
        $insert_query = "INSERT INTO daftar_poli (id_pasien, id_jadwal, keluhan, no_antrian, tanggal, jadwal_periksa, status_periksa, jam_mulai, jam_selesai, poli, dokter) 
                         VALUES ('$id_pasien', '$id_jadwal', '$keluhan', '$no_antrian', NOW(), '$jadwal_periksa', 'belum diperiksa', '$jam_mulai', '$jam_selesai', '$poli', '$dokter')";

        if (mysqli_query($mysqli, $insert_query)) {
            // Redirect ke halaman yang sama dengan status sukses di URL
            header("Location: " . $_SERVER['PHP_SELF'] . "?status=success&no_antrian=$no_antrian&jadwal_periksa=$jadwal_periksa");
            exit; // Pastikan skrip tidak dilanjutkan setelah redirect
        } else {
            // Tampilkan error dari MySQL
            echo "Error: " . mysqli_error($mysqli);
        }
    }
}

// Ambil data poli
$polies = mysqli_query($mysqli, "SELECT * FROM poli");

// Cek status di URL untuk menampilkan pesan
if (isset($_GET['status']) && $_GET['status'] == 'success') {
    $success_message = "Pendaftaran berhasil. Nomor antrian: " . $_GET['no_antrian'] . ". Harap datang pada jadwal dokter yang sudah Anda pilih.";
    $jadwal_periksa = $_GET['jadwal_periksa'];
    $no_antrian = $_GET['no_antrian'];

    // Ambil data pendaftaran untuk detail
    $query_detail = "SELECT * FROM daftar_poli WHERE no_antrian = '$no_antrian' AND jadwal_periksa = '$jadwal_periksa'";
    $result_detail = mysqli_query($mysqli, $query_detail);
    $detail = mysqli_fetch_assoc($result_detail);

    // Ambil detail jadwal
    $query_jadwal = "SELECT jd.jam_mulai, jd.jam_selesai, p.nama_poli, d.nama 
                     FROM jadwal_dokter jd 
                     JOIN dokter d ON jd.id_dokter = d.id 
                     JOIN poli p ON d.id_poli = p.id 
                     WHERE jd.id = '{$detail['id_jadwal']}'"; // Pastikan id_jadwal ada di detail
    $result_jadwal = mysqli_query($mysqli, $query_jadwal);
    $row_jadwal = mysqli_fetch_assoc($result_jadwal);

    // Ambil data dari query
    $jam_mulai = $row_jadwal['jam_mulai'];
    $jam_selesai = $row_jadwal['jam_selesai'];
    $poli = $row_jadwal['nama_poli'];
    $dokter = $row_jadwal['nama'];

    // Hitung hari pemeriksaan
    $hari_pemeriksaan = date('l', strtotime($jadwal_periksa)); // Mengambil nama hari dari tanggal
    $hariMap = [
        'Sunday' => 'Minggu',
        'Monday' => 'Senin',
        'Tuesday' => 'Selasa',
        'Wednesday' => 'Rabu',
        'Thursday' => 'Kamis',
        'Friday' => 'Jumat',
        'Saturday' => 'Sabtu'
    ];
    $hari_pemeriksaan = isset($hariMap[$hari_pemeriksaan]) ? $hariMap[$hari_pemeriksaan] : '';
}

$checkPasienQuery = mysqli_query($mysqli, "SELECT * FROM pasien WHERE id = '$id_pasien'");
if (mysqli_num_rows($checkPasienQuery) === 0) {
    echo "<script>alert('ID pasien tidak valid.');</script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pendaftaran Rawat Jalan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Segoe+UI:w ght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css">
    <style>
        body {
            background-color: #f0f8ff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .header {
            background-color: #0056b3;
            color: white;
            padding: 20px;
            text-align: center;
            margin-bottom: 30px;
        }
        .header, .footer {
            background-color: #0056b3;
            color: white;
            padding: 20px;
        }

        .header h1, .footer h5 {
            margin: 0;
        }

        .footer {
            margin-top: 50px;
            text-align: center;
        }

        .footer a {
            color: white;
        }

        .footer a:hover {
            color: #c82333;
        }

        .container {
            max-width: 800px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 30px;
            margin: 30px auto;
        }

        .form-label {
            color: #0056b3;
            font-weight: 600;
            margin-bottom: 8px;
        }

        .form-select, .form-control {
            border-radius: 10px;
            border: 1px solid #ddd;
            padding: 12px;
            margin-bottom: 20px;
        }

        .form-select:focus, .form-control:focus {
            border-color: #0056b3;
            box-shadow: 0 0 0 0.2rem rgba(0,86,179,0.25);
        }

        .btn {
            padding: 12px 30px;
            border-radius: 50px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background-color: #0056b3;
            border: none;
        }

        .btn-primary:hover {
            background-color: #003f77;
            transform: translateY(-2px);
        }

        .alert {
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 25px;
        }

        .back-link {
            display: inline-block;
            margin: 20px;
            color: #0056b3;
            text-decoration: none;
            font-weight: 600;
        }

        .back-link:hover {
            color: #003f77;
        }

        @media (max-width: 768px) {
            .container {
                margin: 20px;
                padding: 20px;
            }
        }

        .ui-datepicker {
            font-size: 12px;
            width: auto;
            padding: 5px;
        }
        .ui-datepicker td {
            padding: 0;
        }

        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            background-color: #28a745;
            color: white;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Pendaftaran Rawat Jalan</h1>
        <p>Silakan lengkapi form pendaftaran di bawah ini</p>
    </div>

    <a href="dashboardPasien.php" class="back-link">
        &larr; Kembali ke Dashboard
    </a>

    <?php if (!empty($success_message)) { ?>
        <div class="notification">
            <?= $success_message; ?>
        </div>
    <?php } ?>

    <div class="container">
        <?php if (!empty($success_message)) { ?>
            <div class="alert alert-success">
                <h4 class="alert-heading">Pendaftaran Berhasil!</h4>
                <p><?= $success_message; ?></p>
                <ul>
                    <li>Nomor Antrian: <?= $detail['no_antrian']; ?></li>
                    <li>Hari Pemeriksaan: <?= $hari_pemeriksaan; ?></li>
                    <li>Tanggal Pemeriksaan: <?= $jadwal_periksa; ?></li>
                    <li>Poli: <?= $poli; ?></li>
                    <li>Dokter: <?= $dokter; ?></li>
                    <li>Jam Mulai: <?= $jam_mulai; ?></li>
                    <li>Jam Selesai: <?= $jam_selesai; ?></li>
                </ul>
                <a href="riwayatPendaftaran.php" class="btn btn-primary">Lihat Pendaftaran</a>
                <a href="dashboardPasien.php" class="btn btn-secondary">Kembali ke Dashboard</a>
            </div>
        <?php } ?>
        
        <?php if (!empty($error)) { ?>
            <div class="alert alert-danger"><?= $error; ?></div>
        <?php } ?>

        <form method="POST">
            <div class="mb-3">
                <label for="id_poli" class="form-label">Poli</label>
                <select class="form-select" id="id_poli" name="id_poli" required>
                    <option value="">Pilih Poli</option>
                    <?php while ($row = mysqli_fetch_assoc($polies)) { ?>
                        <option value="<?= $row['id']; ?>"><?= $row['nama_poli']; ?></option>
                    <?php } ?>
                </select>
            </div>

            
            <div class="mb-3">
                <label for="id_dokter" class="form-label">Dokter</label>
                <select class="form-select" id="id_dokter" name="id_dokter" required>
                    <option>Pilih Dokter...</option>
                </select>
            </div>

            <div class="mb-3">
                <label for="id_jadwal" class="form-label">Jadwal</label>
                <select class="form-select" id="id_jadwal" name="id_jadwal" required>
                    <option>Pilih Jadwal...</option>
                </select>
            </div>

            <div class="mb-4">
                <label for="keluhan" class="form-label">Keluhan</label>
                <textarea class="form-control" id="keluhan" name="keluhan" rows="3" required></textarea>
            </div>

            <div class="mb-3">
                <label for="tanggal_pemeriksaan" class="form-label">Tanggal Pemeriksaan</label>
                <input type="text" id="tanggal_pemeriksaan" name="tanggal_pemeriksaan" class="form-control" required placeholder="Pilih tanggal pemeriksaan">
            </div>

            <button type="submit" class="btn btn-primary w-100">Daftar Sekarang</button>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const poliSelect = document.getElementById('id_poli');
            const dokterSelect = document.getElementById('id_dokter');
            const jadwalSelect = document.getElementById('id_jadwal');
            const tanggalPemeriksaan = document.getElementById('tanggal_pemeriksaan');

            poliSelect.addEventListener('change', function() {
                const poliId = poliSelect.value;
                dokterSelect.innerHTML = '<option>Pilih Dokter...</option>';
                jadwalSelect.innerHTML = '<option>Pilih Jadwal...</option>';

                if (poliId) {
                    fetch('get_dokter.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: 'id_poli=' + poliId
                    })
                    .then(response => response.json())
                    .then(data => {
                        data.forEach(dokter => {
                            const option = document.createElement('option');
                            option.value = dokter.id;
                            option.textContent = dokter.nama;
                            dokterSelect.appendChild(option);
                        });
                    });
                }
            });

            dokterSelect.addEventListener('change', function() {
                fetchJadwal();
            });

            function fetchJadwal() {
                const dokterId = dokterSelect.value;
                jadwalSelect.innerHTML = '<option>Pilih Jadwal...</option>';

                if (dokterId) {
                    fetch('get_jadwal.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: 'id_dokter=' + dokterId
                    })
                    .then(response => response.json())
                    .then(data => {
                        const hariOrder = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'];
                        data.sort((a, b) => hariOrder.indexOf(a.hari) - hariOrder.indexOf(b.hari));
                        data.forEach(jadwal => {
                            const option = document.createElement('option');
                            option.value = jadwal.id;
                            option.textContent = `${jadwal.hari} - ${jadwal.jam_mulai} - ${jadwal.jam_selesai} - ${jadwal.status_text}`;
                            option.classList.add(jadwal.status_class);

                            if (jadwal.status_class === 'text-danger') {
                                option.disabled = true;
                            }

                            jadwalSelect.appendChild(option);
                        });
                    });
                }
            }

            jadwalSelect.addEventListener('change', function() {
                const selectedOption = jadwalSelect.options[jadwalSelect.selectedIndex];
                const hari = selectedOption.textContent.split(' - ')[0];

                // Aktifkan tanggal di hari yang sesuai dan nonaktifkan tanggal yang sudah terlewat
                $(tanggalPemeriksaan).datepicker("destroy").datepicker({
                    beforeShowDay: function(date) {
                        const day = date.getDay();
                        const hariMap = {
                            'Minggu': 0,
                            'Senin': 1,
                            'Selasa': 2,
                            'Rabu': 3,
                            'Kamis': 4,
                            'Jumat': 5,
                            'Sabtu': 6
                        };
                        const today = new Date();
                        return [day === hariMap[hari] && date >= today, ""];
                    },
                    dateFormat: "yy-mm-dd",
                    minDate: 0 // Nonaktifkan tanggal yang sudah terlewat
                });
            });
        });

        // Close the modal when clicking outside of it
        window.onclick = function(event) {
            if (event.target == document.getElementById('myModal')) {
                document.getElementById('myModal').style.display = "none";
            }
        }

        function downloadPDF() {
            // Implementasi untuk mengunduh PDF
            alert("Fitur unduh PDF belum diimplementasikan.");
        }

        function downloadImage() {
            // Implementasi untuk mengunduh gambar
            alert("Fitur unduh gambar belum diimplementasikan.");
        }

        // Optional: Auto-hide notification after a few seconds
        setTimeout(() => {
            const notification = document.querySelector('.notification');
            if (notification) {
                notification.style.display = 'none';
            }
        }, 5000);
    </script>
    <!-- Footer -->
    <div class="footer">
        <h5>&copy; 2024 Sistem Layanan Kesehatan</h5>
        <p><a href="privacy.php">Kebijakan Privasi</a> | <a href="terms.php">Syarat dan Ketentuan</a></p>
    </div>
</body>
</html>