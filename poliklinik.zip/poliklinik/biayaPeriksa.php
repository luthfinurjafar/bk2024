<?php 
session_start();
include_once("koneksi.php");

// Cek apakah pengguna sudah login
if (!isset($_SESSION['id']) || !isset($_SESSION['nama'])) {
    echo "<script>
        alert('Anda harus login terlebih dahulu');
        window.location.href='loginDokter.php';
    </script>";
    exit;
}

// Validasi parameter GET
if (!isset($_GET['id'])) {
    echo "<script>
        alert('Data tidak lengkap');
        window.location.href='periksa.php';
    </script>";
    exit;
}

$id_daftar_poli = $_GET['id'];

// Ambil data pemeriksaan berdasarkan ID
$periksaQuery = mysqli_query($mysqli, "
    SELECT id, id_daftar_poli, tgl_periksa, catatan, biaya_periksa, biaya_obat, total_biaya, nama_obat 
    FROM periksa 
    WHERE id_daftar_poli = '$id_daftar_poli'
");

if (!$periksaQuery || mysqli_num_rows($periksaQuery) === 0) {
    echo "<script>
        alert('Data pemeriksaan tidak ditemukan');
        window.location.href='periksa.php';
    </script>";
    exit;
}

$periksaData = mysqli_fetch_assoc($periksaQuery);


// Ambil id_pasien dari tabel daftar_poli berdasarkan id_daftar_poli
$id_daftar_poli = $periksaData['id_daftar_poli'];
$daftarPoliQuery = mysqli_query($mysqli, "
    SELECT id_pasien FROM daftar_poli 
    WHERE id = '$id_daftar_poli'
");

if (!$daftarPoliQuery || mysqli_num_rows($daftarPoliQuery) === 0) {
    echo "<script>
        alert('Data pasien tidak ditemukan');
        window.location.href='periksa.php';
    </script>";
    exit;
}

$daftarPoliData = mysqli_fetch_assoc($daftarPoliQuery);
$id_pasien = $daftarPoliData['id_pasien'];

// Ambil data pasien berdasarkan id_pasien
$pasienQuery = mysqli_query($mysqli, "
    SELECT nama, alamat FROM pasien 
    WHERE id = '$id_pasien'
");

if (!$pasienQuery || mysqli_num_rows($pasienQuery) === 0) {
    echo "<script>
        alert('Data pasien tidak ditemukan');
        window.location.href='periksa.php';
    </script>";
    exit;
}

$pasien = mysqli_fetch_assoc($pasienQuery);

// Ambil data dokter dan poli
$id_dokter = $_SESSION['id']; // ID dokter yang sedang login
// echo "ID Dokter: " . htmlspecialchars($id_dokter); // Debugging

$query = "
    SELECT dokter.nama AS nama_dokter, poli.nama_poli 
    FROM dokter 
    JOIN poli ON dokter.id_poli = poli.id 
    WHERE dokter.id = '$id_dokter'
";
$dokterQuery = mysqli_query($mysqli, $query);

if (!$dokterQuery) {
    echo "Error: " . mysqli_error($mysqli); // Menampilkan error jika query gagal
}

if (mysqli_num_rows($dokterQuery) === 0) {
    echo "<script>
        alert('Data dokter tidak ditemukan. Pastikan dokter sudah terdaftar.');
        window.location.href='periksa.php';
    </script>";
    exit;
}

$dokter = mysqli_fetch_assoc($dokterQuery);

// Total biaya
$total_biaya = $periksaData['biaya_periksa'] + $periksaData['biaya_obat'];

// Ambil data dari tabel periksa berdasarkan id_daftar_poli
$id_daftar_poli = isset($_GET['id']) ? $_GET['id'] : null;
$query = mysqli_query($mysqli, "SELECT * FROM periksa WHERE id_daftar_poli = '$id_daftar_poli'");
$periksaData = mysqli_fetch_assoc($query);

// Tampilkan nama_obat
if ($periksaData) {
    $nama_obat = $periksaData['nama_obat']; // Ambil nama obat
} else {
    $nama_obat = 'Tidak ada obat yang dipilih'; // Pesan jika tidak ada obat
}

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rincian Biaya - Poliklinik</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Segoe+UI:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0f8ff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .header {
            background-color: #0056b3;
            color: white;
            padding: 30px 20px;
            text-align: center;
        }

        .header i {
            font-size: 2.5rem;
            margin-bottom: 15px;
        }

        .container {
            max-width: 800px;
            margin: 30px auto;
            padding: 0 20px;
        }

        .card {
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border: none;
            margin-bottom: 30px;
            background: white;
        }

        .card-header {
            background-color: #0056b3;
            color: white;
            border-radius: 15px 15px 0 0 !important;
            padding: 20px;
            text-align: center;
        }

        .success-icon {
            font-size: 2.5rem;
            color: #4ECB71;
            margin-bottom: 15px;
        }

        .table {
            margin-bottom: 0;
        }

        .table th {
            background-color: #f8f9fa;
            font-weight: 600;
            width: 35%;
            padding: 15px;
        }

        .table td {
            padding: 15px;
        }

        .total-row {
            background-color: #f0f8ff;
        }

        .total-row th,
        .total-row td {
            color: #0056b3;
            font-weight: 700;
            font-size: 1.1rem;
        }

        .btn {
            border-radius: 50px;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background-color: #0056b3;
            border: none;
            padding: 10px 25px;
        }

        .btn-back {
            background-color: #6c757d;
            border: none;
            padding: 8px 20px;
            font-size: 0.9rem;
        }

        .back-link {
            color: #0056b3;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            margin: 20px 0;
            font-weight: 500;
        }

        .back-link:hover {
            color: #003d82;
        }

        .print-header {
            text-align: center;
            margin-bottom: 30px;
            display: none;
        }

        .print-header img {
            max-width: 80px;
            margin-bottom: 10px;
        }

        .footer {
            background-color: #0056b3;
            color: white;
            padding: 20px;
            text-align: center;
            margin-top: 50px;
        }

        .footer a {
            color: white;
            text-decoration: none;
        }

        @media print {
            body {
                background-color: white;
            }
            
            .print-header {
                display: block;
            }

            .no-print {
                display: none !important;
            }

            .card {
                box-shadow: none;
                border: none;
            }

            .card-header {
                background-color: white !important;
                color: black !important;
                padding: 0 !important;
            }

            .table th, .table td {
                border: 1px solid #ddd;
            }

            .total-row {
                background-color: #f8f9fa !important;
                -webkit-print-color-adjust: exact;
            }

            .signature-section {
                margin-top: 50px;
                page-break-inside: avoid;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header no-print">
        <i class="fas fa-file-invoice"></i>
        <h1>Rincian Biaya Pemeriksaan</h1>
        <p>Detail pembayaran dan catatan pemeriksaan</p>
    </div>

    <div class="container">
        <a href="periksa.php" class="back-link no-print">
            <i class="fas fa-arrow-left"></i>
            Kembali
        </a>

        <div class="card">
            <div class="card-header">
                <div class="success-icon">
                    <i class="fas fa-check-circle"></i>
                </div>
                <h2>Rincian Biaya Pemeriksaan</h2>
            </div>
            <div class="card-body">
                <table class="table table-bordered">
                    <tr>
                        <th>Nama Pasien</th>
                        <td><?= htmlspecialchars($pasien['nama']); ?></td>
                    </tr>
                    <tr>
                        <th>Alamat</th>
                        <td><?= htmlspecialchars($pasien['alamat']); ?></td>
                    </tr>
                    <tr>
                        <th>Nama Dokter</th>
                        <td><?= htmlspecialchars($dokter['nama_dokter']); ?></td>
                    </tr>
                    <tr>
                        <th>Nama Poli</th>
                        <td><?= htmlspecialchars($dokter['nama_poli']); ?></td>
                    </tr>
                </table>

                <!-- Tabel kedua untuk biaya dan catatan -->
                <table class="table table-bordered mt-4">
                    <tr>
                        <th>ID</th>
                        <td><?= htmlspecialchars($periksaData['id']); ?></td>
                    </tr>
                    <tr>
                        <th>ID Daftar Poli</th>
                        <td><?= htmlspecialchars($periksaData['id_daftar_poli']); ?></td>
                    </tr>
                    <tr>
                        <th>Tanggal Periksa</th>
                        <td><?= htmlspecialchars($periksaData['tgl_periksa']); ?></td>
                    </tr>
                    <tr>
                        <th>Resep Obat</th>
                        <td><?= htmlspecialchars($nama_obat); ?></td>
                    </tr>
                    <tr>
                        <th>Catatan</th>
                        <td><?= htmlspecialchars($periksaData['catatan']); ?></td>
                    </tr>
                
                    <tr>
                        <th>Biaya Pemeriksaan</th>
                        <td>Rp <?= number_format($periksaData['biaya_periksa'], 0, ',', '.'); ?></td>
                    </tr>
                    <tr>
                        <th>Biaya Obat</th>
                        <td>Rp <?= number_format($periksaData['biaya_obat'], 0, ',', '.'); ?></td>
                    </tr>
                    <tr>
                        <th>Total Biaya</th>
                        <td>Rp <?= number_format($periksaData['total_biaya'], 0, ',', '.'); ?></td>
                    </tr>
                    
                </table>

                <div class="text-center mt-4 mb-4">
                    <button onclick="window.print()" class="btn btn-primary no-print">
                        <i class="fas fa-print me-2"></i>
                        Cetak Rincian
                    </button>
                    <a href="periksa.php" class="btn btn-secondary btn-back no-print ms-2">
                        <i class="fas fa-arrow-left me-1"></i>
                        Kembali
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <div class="footer no-print">
        <h5>&copy; 2024 Sistem Layanan Kesehatan</h5>
        <p><a href="privacy.php">Kebijakan Privasi</a> | <a href="terms.php">Syarat dan Ketentuan</a></p>
    </div>
</body>
</html>
